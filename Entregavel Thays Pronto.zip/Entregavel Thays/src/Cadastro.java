import javax.swing.*;

public class Cadastro {
    private JButton btn1;
}
