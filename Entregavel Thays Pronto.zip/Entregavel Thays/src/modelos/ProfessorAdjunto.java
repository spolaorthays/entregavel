package modelos;

public class ProfessorAdjunto extends Professor{

    private Integer quantidadeHorasMonitoria;

    public Integer getQuantidadeHorasMonitoria() {
        return quantidadeHorasMonitoria;
    }

    public void setQuantidadeHorasMonitoria(Integer quantidadeHorasMonitoria) {
        this.quantidadeHorasMonitoria = quantidadeHorasMonitoria;
    }
}
